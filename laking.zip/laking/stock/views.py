from django.shortcuts import render, redirect
from .models import Product, ProductHistory
from .forms import *
from django.http import HttpResponse
import csv
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
import weasyprint
from weasyprint import HTML, CSS

# Create your views here.
def home(request):
    title = 'Home Page'
    context = {
    "title": title,
    }
    # return redirect('/list_items')
    return render(request, "home.html",context)
    

@login_required
def add_items(request):
    form = ProductCreateForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Product successfully added')
        return redirect("/list_items")
    context = {
		"form": form,
		"title": "Add New Product",
	}
    return render(request, "add_items.html", context)

@login_required
def list_items(request):
    header="All Products"
    form = ProductSearchForm(request.POST or None)
    queryset = Product.objects.all()
    # category = form['category'].value()
    context={    
        "form":form,
        "queryset":queryset,
        "header":header
            }
    if request.method == 'POST':
        queryset = Product.objects.filter(category__id__icontains=form['category'].value(),
        item_name__icontains=form['item_name'].value())
        if form['export_to_CSV'].value() == True:
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="List of Product.csv"'
            writer = csv.writer(response)
            writer.writerow(['CATEGORY', 'PRODUCT NAME', 'QUANTITY'])
            instance = queryset
            for product in instance:
                writer.writerow([product.category, product.item_name, product.quantity])
            return response
        context={
            "form": form,
            "queryset":queryset,
            "header":header
            }
    return render(request,"list_items.html", context)


def update_items(request, pk):
    queryset = Product.objects.get(id=pk)
    form = ProductUpdateForm(instance=queryset)
    if request.method == 'POST':
        form = ProductUpdateForm(request.POST, instance=queryset)
        if form.is_valid():
            form.save()
            messages.success(request, "updated success")
            return redirect('/list_items')

    context = {
    'form':form
    }
    return render(request, 'add_items.html', context)


def delete_items(request, pk):
    queryset = Product.objects.get(id=pk)
    if request.method == 'POST':
        queryset.delete()
        messages.success(request, "Delete successful")
        return redirect('/list_items')
    return render(request, 'delete_items.html')


def product_detail(request, pk):
    queryset = Product.objects.get(id=pk)
    context = {
    "queryset": queryset,
    }
    return render(request, "product_detail.html", context)


def issue_items(request, pk):
    queryset = Product.objects.get(id=pk)
    form = IssueForm(request.POST or None, instance=queryset)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.receive_quantity=0
        instance.quantity -= instance.issue_quantity
        instance.issue_by = str(request.user)
        messages.success(request, "ISSUED SUCCESSFULLY. " + str(instance.quantity) + " " + str(instance.item_name) + "s now left in Store")
        instance.save()

        return redirect('/product_detail/'+str(instance.id))
        # return HttpResponseRedirect(instance.get_absolute_url())

    context = {
        "title": 'Issue ' + str(queryset.item_name),
        "queryset": queryset,
        "form": form,
        "username": 'Issue By: ' + str(request.user),
    }
    return render(request, "add_items.html", context)


def receive_items(request, pk):
    queryset = Product.objects.get(id=pk)
    form = ReceiveForm(request.POST or None, instance=queryset)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.issue_quantity=0
        instance.quantity += instance.receive_quantity
        instance.receive_by=str(request.user)
        instance.save()
        messages.success(request, "Received SUCCESSFULLY. " + str(instance.quantity) + " " + str(instance.item_name)+"s now in Store")

        return redirect('/product_detail/'+str(instance.id))
        # return HttpResponseRedirect(instance.get_absolute_url())
    context = {
        "title": 'Receive ' + str(queryset.item_name),
        "instance": queryset,
        "form": form,
        "username": 'Receive By: ' + str(request.user),
    }
    return render(request, "add_items.html", context)


def reorder_level(request, pk):
    queryset = Product.objects.get(id=pk)
    form = ReorderLevelForm(request.POST or None, instance=queryset)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        messages.success(request, "Reorder level for " + str(instance.item_name) + " is updated to " + str(instance.reorder_level))
        return redirect("/list_items")
    context = {
        "instance": queryset,
        "form": form,
    }
    return render(request, "add_items.html", context)


@login_required
def list_history(request):
    header = 'DAILY TRANSACTIONS'
    queryset = ProductHistory.objects.all().order_by('-last_updated')
    form = ProductHistorySearchForm(request.POST or None)
    context = {
    "header": header,
    "queryset": queryset,
    "form":form,
    }
    
    if request.method == 'POST':
        category = form['category'].value()
        queryset = ProductHistory.objects.filter(item_name__icontains=form['item_name'].value(),
                               last_updated__range=[
                                                form['start_date'].value(),
                                                form['end_date'].value()
                                            ]
        ).order_by('-last_updated')
       

        if (category != ''):
            queryset = queryset.filter(category_id=category)
        
        if form['export_to_CSV'].value() == True:
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="Product History.csv"'
            writer = csv.writer(response)
            writer.writerow(
                ['CATEGORY', 
                'ITEM NAME',
                'QUANTITY', 
                'ISSUE QUANTITY', 
                'RECEIVE QUANTITY', 
                'RECEIVE BY', 
                'ISSUE BY', 
                'LAST UPDATED'])
            instance = queryset
            for product in instance:
                writer.writerow(
                [product.category, 
                product.item_name, 
                product.quantity, 
                product.issue_quantity, 
                product.receive_quantity, 
                product.receive_by, 
                product.issue_by, 
                product.last_updated])
            return response

        context = {
            "form": form,
            "header": header,
            "queryset": queryset,
            }
    return render(request, "list_history.html",context)


@login_required
def sales_report(request):
    header = 'GENERATE REPORT'
    aggregate=0
    queryset = ProductHistory.objects.all().order_by('-last_updated')
    for x in queryset:
        queryset1=Product.objects.filter(item_name=x.item_name)
        for y,z in zip(queryset1,queryset):
            total=y.unit_cost_price * z.issue_quantity
            aggregate += total
    form = SalesReportSearchForm(request.POST or None)
    context = {
    "header": header,
    "queryset": queryset,
    "queryset1":queryset1,
    "total":total,
    "aggregate":aggregate,
    "form":form,
    }
    
    if request.method == 'POST':
        category = form['category'].value()
        queryset = ProductHistory.objects.filter(item_name__icontains=form['item_name'].value(),
                               last_updated__range=[
                                                form['start_date'].value(),
                                                form['end_date'].value()
                                            ]
        ).order_by('-last_updated')
        for x in queryset:
            queryset1=Product.objects.filter(item_name=x.item_name)
            for y,z in zip(queryset1,queryset):
                total=y.unit_cost_price * z.issue_quantity
                aggregate += total

        if (category != ''):
            queryset = queryset.filter(category_id=category)
        
        if request.POST.get('pdf'):
            html = render_to_string('report.html',{'queryset':queryset, 'header':header, 'queryset1':queryset1, "total":total,"aggregate":aggregate})
            response = HttpResponse(content_type='application/pdf')
            response['Content-Disposition'] = 'filename=001.pdf'
            weasyprint.HTML(string=html).write_pdf(response, stylesheets=[CSS(string='body{size:20px}')])
            order_pdf = HTML(string=html).write_pdf()
            return response

        context = {
            "form": form,
            "header": header,
            "queryset": queryset,
            "queryset1":queryset1,
            "total":total,
            "aggregate":aggregate
            }
    return render(request, "sales_report.html",context)


