from django.contrib import admin
from .models import Product, Category
from .forms import ProductCreateForm
# Register your models here.

class ProductCreateAdmin(admin.ModelAdmin):
   list_display = ['category', 'item_name', 'quantity']
   form = ProductCreateForm
   list_filter = ['category']
   search_fields = ['category__name', 'item_name']

admin.site.register(Product,ProductCreateAdmin)
admin.site.register(Category)
