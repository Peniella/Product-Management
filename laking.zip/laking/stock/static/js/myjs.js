$(document).ready(function(){

  $('.table').paging({limit:10});
  $(".datetimeinput").datepicker({changeYear: true,changeMonth: true, dateFormat: 'yy-mm-dd'});
   
   
  });

  